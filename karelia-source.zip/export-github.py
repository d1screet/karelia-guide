from pathlib import Path
import shutil,json,zipfile
root=Path(__file__).resolve().parent;d=root/'dist';out=root/'github-export'
out.mkdir(exist_ok=True)
for p in out.iterdir():
 if p.is_file() and p.name!='karelia-source.zip':p.unlink()
for p in d.iterdir():
 if p.is_file():shutil.copy2(p,out/p.name)
for p in (d/'assets').rglob('*'):
 if p.is_file():shutil.copy2(p,out/p.name)
for name in ['index.html','app.js','data.json','assets.json']:
 p=out/name;s=p.read_text().replace('assets/','');p.write_text(s)
p=out/'leaflet.css';p.write_text(p.read_text().replace('url(images/','url('))
(out/'README.md').write_text('# Карелия: между культурой и тишиной\n\n[Открыть сайт](https://d1screet.github.io/karelia-guide/) — без входа в ChatGPT и GitHub.\n\nИнтерактивная карта, два маршрута, десять уникальных мест и фестивальный бонус.\n\nHTML/CSS/JavaScript, локальная Leaflet, реальные лицензированные фотографии. Данные — data.json, авторы и лицензии — assets.json и PHOTO-CREDITS.md. Сборка и платные ключи не нужны.\n\nДля локального запуска: `python3 -m http.server 4173`, затем http://localhost:4173.\n\nИсходники в первоначальной структуре с инструкцией и журналом проверки также доступны в karelia-source.zip. GitHub Pages: main, / (root).\n')
print('Files:',len(list(out.iterdir())))

with zipfile.ZipFile(out/'karelia-source.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in d.rglob('*'):
  if p.is_file():z.write(p,'dist/'+str(p.relative_to(d)))
 for n in ['README.md','QA.md','GITHUB.md','export-github.py']:
  if (root/n).exists():z.write(root/n,n)
